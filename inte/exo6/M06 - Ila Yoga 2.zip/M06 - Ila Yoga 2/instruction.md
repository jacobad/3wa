# INSTRUCTIONS
Découverte des tableaux et des formulaires

## HTML
- Utilisation du normalize.css
- Utilisation des balises pour le tableau et pour les formulaires

## CSS
- Largeur du tableau : 90%
- Taille de la police :
    - par défaut : 1em
    - caption : 2em
    - thead : 1.6em

- Police utilisés :
    - thead et caption : "Kaushan Script"
    - Texte : "Playfair Display"

## BONUS

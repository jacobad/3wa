# INSTRUCTIONS
Révision et approfondissement du float et du inline-block

## HTML
- Utilisation du normalize.css

## CSS
- Utilisation du inline-block et du float pour le placement de certains éléments
- Taille de la police :
    - par défaut : 1em
    - nav : 1.5em
    - titre header : 2em

- Police utilisés :
    - Titre et Nav : "Kaushan Script"
    - Texte : "Playfair Display"

## BONUS
- Trouver comment on intègre une google map

## La propriété box-sizing
https://developer.mozilla.org/fr/docs/Web/CSS/box-sizing
http://www.binvisions.com/wp-content/uploads/2011/09/css-box-model-border-content_590x328.jpg

## La propriété background-size
https://developer.mozilla.org/fr/docs/Web/CSS/background-size

## La propriété background-position
https://developer.mozilla.org/fr/docs/Web/CSS/background-position

## Les balises HTML5 sémantique
http://www.alsacreations.com/article/lire/1376-html5-section-article-nav-header-footer-aside.html

## Bonnes pratiques des déclarations @font-face :
http://typographisme.net/post/Bonnes-pratiques-pour-les-d%C3%A9clarations-@font-face

## La propriété font-size
https://developer.mozilla.org/fr/docs/Web/CSS/font-size

## La propriété font-weight
https://developer.mozilla.org/fr/docs/Web/CSS/font-weight

## La propriété font-style
https://developer.mozilla.org/fr/docs/Web/CSS/@font-face/font-style

## La propriété text-align
https://developer.mozilla.org/fr/docs/Web/CSS/text-align

## La propriété text-transform
https://developer.mozilla.org/fr/docs/Web/CSS/text-transform

## La propriété text-decoration
https://developer.mozilla.org/fr/docs/Web/CSS/text-decoration

## Différence entre les éléments de type block et de type inline
https://blog.4psa.com/wp-content/uploads/block-inline1.png

## La propriété width
https://developer.mozilla.org/fr/docs/Web/CSS/@media/width

## La propriété margin
https://developer.mozilla.org/fr/docs/Web/CSS/margin

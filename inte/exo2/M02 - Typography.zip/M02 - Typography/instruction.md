# INSTRUCTIONS
Comprendre le fonctionnement de la typographie sur le Web.

## HTML
- Utilisation des balises sémantiques basique

## CSS
- Largeur du site à 50%
- Police utilisé :
    - Titre : Blacksword
    - Texte : Cardo
- Taille de police :
    - par défaut : 1.4em / line-height : 50px / text-indent : 25px
    - h1 : 4em
    - h2 : 2.5em / word-spacing : 25px
    - h3 : 1.5em / word-spacing : 10px

## BONUS
Limiter la taille du contenu à 800px maximum

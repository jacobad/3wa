## Le hover
https://developer.mozilla.org/fr/docs/Web/CSS/:hover

## Guide de survie du positionnement en CSS
http://www.alsacreations.com/article/lire/53-guide-de-survie-du-positionnement-css.html

## Tooltip menu déroulant en CSS
http://www.frogweb.fr/menu-deroulant-horizontal/

## La propriété z-index
http://www.alsacreations.com/astuce/lire/84-comment-fonctionne-la-proprit-css-z-index.html

## Le poids en CSS
http://www.commentcamarche.net/faq/33023-les-poids-css
